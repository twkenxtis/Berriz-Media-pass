// background.js (Firefox 版, Manifest V2)

console.log("Background.js loaded");

// 測試讀取 https://berriz.in 的所有 Cookies（除錯用）
browser.cookies
  .getAll({ url: "https://berriz.in" })
  .then((cookies) => {
    console.log("All cookies for berriz.in:", cookies);
  })
  .catch((error) => {
    console.error("Failed to get cookies:", error);
  });

// 儲存播放資料，最多七組，以 UUID 為鍵
let playbackCache = new Map();

// 當標籤更新時，監聽 URL 變化
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    console.log(`Tab updated: ${changeInfo.url}`);
    checkBerrizUrl(changeInfo.url, tabId);
  }
});

// 檢查網址是否符合 Berriz 的格式
function checkBerrizUrl(url, tabId) {
  const replayPattern =
    /^https:\/\/berriz\.in\/[a-z]{2}\/[^/]+\/live\/replay\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;
  const mediaPattern =
    /^https:\/\/berriz\.in\/[a-z]{2}\/[^/]+\/(?:media\/content\/)+([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;

  let uuid = null;
  let apiEndpoint = null;
  let titleEndpoint = null;

  if (replayPattern.test(url)) {
    uuid = url.match(replayPattern)[1];
    apiEndpoint = `https://svc-api.berriz.in/service/v1/medias/live/replay/${uuid}/playback_area_context`;
    // live replay 的 title 已包含於 playback_area_context 中
  } else if (mediaPattern.test(url)) {
    uuid = url.match(mediaPattern)[1];
    apiEndpoint = `https://svc-api.berriz.in/service/v1/medias/${uuid}/playback_info`;
    titleEndpoint = `https://svc-api.berriz.in/service/v1/medias/${uuid}/public_context`;
  }

  if (uuid && apiEndpoint) {
    // Manifest V2 下使用 chrome.browserAction
    chrome.browserAction.setBadgeText({ text: "!", tabId: tabId });
    chrome.browserAction.setBadgeBackgroundColor({
      color: "#FF5252",
      tabId: tabId,
    });
    if (!playbackCache.has(uuid)) {
      console.log(`Fetching media info for UUID: ${uuid}`);
      fetchMediaInfo(uuid, apiEndpoint, titleEndpoint);
    }
  } else {
    chrome.browserAction.setBadgeText({ text: "", tabId: tabId });
  }
}

// 處理來自彈出視窗的訊息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getPlaybackCache") {
    sendResponse({ cache: Array.from(playbackCache.entries()) });
  } else if (request.action === "clearPlaybackCache") {
    playbackCache.clear();
    console.log("Playback cache cleared");
    sendResponse({ success: true });
  }
});

// 獲取媒體資訊
async function fetchMediaInfo(uuid, apiEndpoint, titleEndpoint) {
  try {
    // 獲取必要的 cookies - 使用 Firefox 的 browser.cookies API
    const cookieNames = ["bz_a", "bz_r", "paccode", "pcid"];
    const cookies = await Promise.all(
      cookieNames.map((name) =>
        browser.cookies.get({ url: "https://berriz.in", name })
      )
    );

    const cookieHeader = cookies
      .filter((cookie) => cookie)
      .map((cookie) => `${cookie.name}=${cookie.value}`)
      .join("; ");

    if (!cookieHeader) {
      throw new Error(
        "Required cookies (bz_a, bz_r, paccode, pcid) not found. Please ensure you are logged into berriz.in."
      );
    }

    // 發送 API 請求以取得播放資訊
    const response = await fetch(apiEndpoint, {
      headers: {
        Cookie: cookieHeader,
        "Content-Type": "application/json",
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (response.status === 401) {
      throw new Error("401 Unauthorized: Please refresh the page");
    }

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`);
    }

    const data = await response.json();

    if (data.code === "FS_MD9010") {
      const err = new Error("Fan Club Exclusive");
      err.code = "FS_MD9010";
      err.fanclubOnly = true;
      throw err;
    }

    if (data.code !== "0000" || !data.data) {
      throw new Error("Invalid API response");
    }

    // 處理回應（支援 live replay 與 media）
    let media = null;
    let title = null;
    if (apiEndpoint.includes("live/replay")) {
      media = data.data.media?.live?.replay || data.data.media;
      title = data.data.media?.title || null;
    } else {
      media = data.data.vod || data.data.media;
    }

    // 處理無效 media 資料
    if (!media) {
      console.error(`No valid media data found for UUID ${uuid}`);
      return; // 無效媒體（包括 YouTube），丟棄回應，不存快取，不通知 popup
    }

    // 如果有 titleEndpoint，進行額外請求以取得 title（適用於 /media/content/）
    if (titleEndpoint) {
      try {
        const titleResponse = await fetch(titleEndpoint, {
          headers: {
            Cookie: cookieHeader,
            "Content-Type": "application/json",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          },
        });

        if (titleResponse.status === 401) {
          throw new Error("401 Unauthorized: Please refresh the page");
        }

        if (titleResponse.ok) {
          const titleData = await titleResponse.json();
          if (titleData.code === "0000" && titleData.data?.media?.title) {
            title = titleData.data.media.title;
          }
        }
      } catch (titleError) {
        console.warn(
          `Failed to fetch title for UUID ${uuid}:`,
          titleError.message
        );
        // 保留 title 為 null
      }
    }

    // 嘗試解碼 title（例如將 "\uD83C\uDF40" 轉換為 🍀）
    if (title) {
      try {
        title = decodeURIComponent(
          title.replace(/\\u[\dA-F]{4}/gi, (match) => {
            return String.fromCharCode(parseInt(match.replace(/\\u/g, ""), 16));
          })
        );
      } catch (e) {
        console.warn(`Failed to decode title for UUID ${uuid}:`, e.message);
        title = null;
      }
    }

    // 組裝 playback data
    const playbackData = {
      isDrm: !!media.isDrm,
      hls: [],
      dash: [],
      hlsVariants: media.hls?.adaptationSet || [],
      timestamp: Date.now(),
      title: title || uuid, // 若無標題，則使用 UUID
    };

    if (!media.isDrm && media.hls?.playbackUrl) {
      playbackData.hls = [media.hls.playbackUrl].filter((url) => url);
    }
    if (!media.isDrm && media.dash?.playbackUrl) {
      playbackData.dash = [media.dash.playbackUrl].filter((url) => url);
    }

    // 更新快取
    playbackCache.set(uuid, playbackData);
    if (playbackCache.size > 7) {
      const oldestEntry = Array.from(playbackCache.entries()).reduce(
        (oldest, current) =>
          current[1].timestamp < oldest[1].timestamp ? current : oldest
      );
      playbackCache.delete(oldestEntry[0]);
      console.log(`Removed oldest cache entry: ${oldestEntry[0]}`);
    }

    console.log(`Playback data updated (${uuid}):`, playbackData);
  } catch (error) {
    const errorEntry = {
      isDrm: null, // 因為無法確定 DRM，設為 null
      hls: [],
      dash: [],
      error: {
        message: error.message || String(error),
        code: error.code || null, // 如果自訂錯誤有 code
        fanclubOnly: !!error.fanclubOnly, // 若為 Fanclub 限定
        stack: error.stack || null, // 可選：除錯用
      },
      timestamp: Date.now(),
      title: uuid,
    };

    playbackCache.set(uuid, errorEntry);
    console.error(
      `Failed to fetch media info (${uuid}):`,
      error.message || error
    );
  }
}
