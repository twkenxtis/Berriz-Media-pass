console.log("Berriz Media Helper 內容腳本已載入:", window.location.href);
