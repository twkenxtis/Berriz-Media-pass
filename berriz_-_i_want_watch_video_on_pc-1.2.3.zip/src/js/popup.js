document.addEventListener("DOMContentLoaded", async () => {
  const statusDiv = document.getElementById("status");
  const errorDiv = document.getElementById("error");
  const mediaListDiv = document.getElementById("media-list");
  const clearListButton = document.getElementById("clear-list");
  const refreshContainer = document.getElementById("refresh-container");
  const refreshButton = document.getElementById("refresh-button");

  // 定義 16:9 解析度字典
  const resolutionMap = [
    { width: 256, height: 144, label: "144p" },
    { width: 640, height: 360, label: "360p" },
    { width: 854, height: 480, label: "480p" },
    { width: 1280, height: 720, label: "720p" },
    { width: 1600, height: 900, label: "900p" },
    { width: 1706, height: 960, label: "960p" },
    { width: 1920, height: 1080, label: "1080p" },
    { width: 3840, height: 2160, label: "4K" },
    { width: 7680, height: 4320, label: "8K" },
  ];

  // 解析度匹配函數，考慮直向影片
  function normalizeResolution(width, height) {
    let w = parseInt(width);
    let h = parseInt(height);
    let isVertical = h > w;

    // 若為直向影片，交換寬高
    if (isVertical) {
      [w, h] = [h, w];
    }

    // 匹配字典，允許 ±10% 誤差
    for (const res of resolutionMap) {
      const widthDiff = Math.abs(w - res.width) / res.width;
      const heightDiff = Math.abs(h - res.height) / res.height;
      if (widthDiff <= 0.1 && heightDiff <= 0.1) {
        return {
          width: res.width,
          height: res.height,
          label: res.label,
          isVertical,
        };
      }
    }

    // 未匹配則返回原始值
    return {
      width: isVertical ? h : w,
      height: isVertical ? w : h,
      label: `${w}x${h}`,
      isVertical,
    };
  }

  // 載入語言
  let langData = {};
  const currentLang = getBrowserLanguage();
  await loadLanguage(currentLang);

  function renderUI() {
    document.querySelectorAll("[data-i18n]").forEach((element) => {
      const key = element.getAttribute("data-i18n");
      element.textContent = langData[key] || element.textContent;
    });
  }
  renderUI();

  refreshButton.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.reload(tabs[0].id);
        showError(langData.page_reloaded || "Page reloaded");
        refreshContainer.classList.add("hidden");
      }
    });
  });

  clearListButton.addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ action: "clearPlaybackCache" });
    mediaListDiv.innerHTML = "";
    showError(langData.cleared_list || "List cleared");
    console.log("Clear list button clicked");
  });

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length === 0) {
      showError(langData.no_tab || "Unable to get current tab");
      return;
    }

    const url = tabs[0].url;
    const uuid = extractUuidFromUrl(url);
    chrome.runtime.sendMessage({ action: "getPlaybackCache" }, (response) => {
      if (!response || !response.cache || response.cache.length === 0) {
        showError(langData.no_data || "No available playback data");
        return;
      }

      statusDiv.classList.add("hidden");
      renderMediaList(response.cache, uuid);
    });

    console.log(`Current tab URL: ${url}, UUID: ${uuid}`);
  });

  async function loadLanguage(lang) {
    try {
      const response = await fetch(
        chrome.runtime.getURL(`src/lang/${lang}.json`)
      );
      langData = await response.json();
      renderUI();
    } catch (error) {
      console.error("Failed to load language:", error);
      langData = {};
      showError(langData.lang_failed || "Failed to load language");
      renderUI();
    }
  }

  function getBrowserLanguage() {
    const lang = navigator.language.toLowerCase();
    const langMap = {
      en: "en",
      "zh-tw": "zh-tw",
      "zh-hk": "zh-tw",
      "zh-cn": "zh-cn",
      zh: "zh-cn",
      ja: "ja",
      ko: "ko",
    };
    return langMap[lang] || langMap[lang.split("-")[0]] || "en";
  }

  function extractUuidFromUrl(url) {
    const urlPatterns = [
      /^https:\/\/berriz\.in\/[a-z]{2}\/[^/]+\/live\/replay\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i,
      /^https:\/\/berriz\.in\/[a-z]{2}\/[^/]+\/(?:media\/content\/)+([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i,
    ];
    for (const pattern of urlPatterns) {
      const match = url.match(pattern);
      if (match) {
        console.log("match", match);
        return match[1];
      }
    }
    return null;
  }

  function showError(message) {
    errorDiv.textContent = message;
    errorDiv.classList.remove("hidden");
    statusDiv.classList.add("hidden");
    if (message.toLowerCase().includes("401 unauthorized")) {
      refreshContainer.classList.remove("hidden");
    } else {
      refreshContainer.classList.add("hidden");
    }
    setTimeout(() => {
      errorDiv.classList.add("hidden");
      refreshContainer.classList.add("hidden");
    }, 5000);
  }

  function renderMediaList(cache, currentUuid) {
    mediaListDiv.innerHTML = "";
    cache.forEach(([mediaId, data]) => {
      const mediaDiv = document.createElement("div");
      mediaDiv.className = "media-item";

      const header = document.createElement("header");
      header.className = "media-header";
      header.textContent =
        data.title || `${langData.media_uuid || "Media UUID"}: ${mediaId}`;
      header.addEventListener("click", () => {
        const content = mediaDiv.querySelector(".media-content");
        content.classList.toggle("hidden");
        header.classList.toggle("collapsed");
      });
      mediaDiv.appendChild(header);

      const content = document.createElement("div");
      content.className = `media-content ${
        mediaId === currentUuid ? "" : "hidden"
      }`;
      if (data.error) {
        const errorP = document.createElement("p");
        errorP.className = "error";
        errorP.textContent = `${langData.error || "Error"}: ${data.error}`;
        content.appendChild(errorP);
        if (data.error.toLowerCase().includes("401 unauthorized")) {
          showError(data.error);
        }
      } else if (
        data.isDrm ||
        (data.hls.length === 0 && data.dash.length === 0)
      ) {
        const drmP = document.createElement("p");
        drmP.className = "warning";
        drmP.textContent =
          langData.drm_protected ||
          "This content is DRM protected or has no available playback URLs";
        content.appendChild(drmP);
      } else {
        const hlsSection = document.createElement("div");
        hlsSection.className = "stream-section";
        const hlsTitle = document.createElement("h3");
        hlsTitle.textContent = "HLS";
        hlsSection.appendChild(hlsTitle);

        if (data.hls.length > 0) {
          addStreamUrl(
            hlsSection,
            langData.master_hls || "Master HLS",
            data.hls[0]
          );
          if (data.hlsVariants && data.hlsVariants.length > 0) {
            const variantsDiv = document.createElement("div");
            variantsDiv.className = "variants hidden";
            const normalizedVariants = data.hlsVariants.map((variant) => {
              const res = normalizeResolution(variant.width, variant.height);
              return { ...variant, normalized: res };
            });

            normalizedVariants.forEach((variant) => {
              addStreamUrl(
                variantsDiv,
                variant.normalized.label,
                variant.playbackUrl
              );
            });
            hlsSection.appendChild(variantsDiv);

            // 按高度排序（由大到小）
            const resolutions = normalizedVariants
              .map((v) => ({
                height: v.normalized.height,
                label: v.normalized.label,
              }))
              .sort((a, b) => b.height - a.height);

            const toggleButton = document.createElement("button");
            toggleButton.className = "toggle-variants";
            toggleButton.textContent = `${resolutions[0].label} - ${
              resolutions[resolutions.length - 1].label
            }`; // 例如 "1080p - 360p"
            toggleButton.addEventListener("click", () => {
              variantsDiv.classList.toggle("hidden");
            });
            hlsSection.appendChild(toggleButton);
          }
        } else {
          hlsSection.innerHTML += `<p>${
            langData.no_hls || "No available HLS URLs"
          }</p>`;
        }
        content.appendChild(hlsSection);

        const dashSection = document.createElement("div");
        dashSection.className = "stream-section";
        const dashTitle = document.createElement("h3");
        dashTitle.textContent = "DASH";
        dashSection.appendChild(dashTitle);
        if (data.dash && data.dash.length > 0) {
          data.dash.forEach((url, index) => {
            addStreamUrl(dashSection, `DASH ${index + 1}`, url);
          });
        } else {
          dashSection.innerHTML += `<p>${
            langData.no_data || "No data available"
          }</p>`;
        }
        content.appendChild(dashSection);
      }
      mediaDiv.appendChild(content);
      mediaListDiv.appendChild(mediaDiv);
    });
  }

  function addStreamUrl(container, label, url) {
    const urlDiv = document.createElement("div");
    urlDiv.className = "stream-url";

    const labelSpan = document.createElement("span");
    labelSpan.textContent = `${label}: `;
    urlDiv.appendChild(labelSpan);

    const urlLink = document.createElement("a");
    urlLink.href = url;
    urlLink.textContent = url;
    urlLink.target = "_blank";
    urlDiv.appendChild(urlLink);

    const copyButton = document.createElement("button");
    copyButton.className = "action-button copy";
    copyButton.textContent = langData.copy || "Copy";
    copyButton.addEventListener("click", () => {
      navigator.clipboard.writeText(url).then(() => {
        copyButton.textContent = langData.copied || "Copied";
        setTimeout(
          () => (copyButton.textContent = langData.copy || "Copy"),
          1000
        );
      });
    });
    urlDiv.appendChild(copyButton);

    const onlineButton = document.createElement("button");
    onlineButton.className = "action-button online";
    onlineButton.textContent = langData.online_play || "Online Play";
    onlineButton.addEventListener("click", () => {
      chrome.tabs.create({
        url: chrome.runtime.getURL(
          `src/player.html?url=${encodeURIComponent(url)}`
        ),
      });
    });
    urlDiv.appendChild(onlineButton);

    const potButton = document.createElement("button");
    potButton.className = "action-button potplayer";
    potButton.textContent = "PotPlayer";
    potButton.addEventListener("click", () => {
      const potUrl = `potplayer://${url}`;
      window.open(potUrl, "_blank");
    });
    urlDiv.appendChild(potButton);

    container.appendChild(urlDiv);
  }
});
